package com.java.repositories;

public class QueryBuilder {
	public static final String EMPLOYEE_INSERT = "INSERT INTO TBL_EMP(FIRST_NAME,LAST_NAME) VALUES(:FN,:LN)";
	public static final String EMPLOYEE_INSERT_1 = "INSERT INTO TBL_EMP(FIRST_NAME,LAST_NAME) VALUES(:firstName,:lastName)";
	public static final String EMPLOYEE_SQL_UPDATE = "UPDATE TBL_EMP SET FIRST_NAME=:firstName,LAST_NAME=:lastName WHERE EMP_ID=:empId";
	public static final String EMPLOYEE_SQL_DELETE = "DELETE FROM TBL_EMP WHERE EMP_ID=:empId";
}
