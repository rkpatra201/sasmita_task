package com.java.repositories;

import javax.sql.DataSource;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.namedparam.BeanPropertySqlParameterSource;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import com.java.model.EmployeeModel;

@Repository
public class EmployeeDao {

	NamedParameterJdbcTemplate namedParameterJdbcTemplate;

	@Autowired
	public void setDataSource(DataSource dataSource) {
		this.namedParameterJdbcTemplate = new NamedParameterJdbcTemplate(
				dataSource);
	}

	public int insertEmployee(EmployeeModel model) {
		SqlParameterSource namedParameters = null;
		/*
		 * namedParameters = new MapSqlParameterSource(). addValue("FN",
		 * model.getFirstName()). addValue("LN",model.getLastName());
		 */
		SqlParameterSource namedParameters1 = new BeanPropertySqlParameterSource(
				model);
		return namedParameterJdbcTemplate.update(
				QueryBuilder.EMPLOYEE_INSERT_1, namedParameters1);

	}

	public int updateEmployee(EmployeeModel model) {
		SqlParameterSource namedParameters = new BeanPropertySqlParameterSource(
				model);

		return namedParameterJdbcTemplate.update(
				QueryBuilder.EMPLOYEE_SQL_UPDATE, namedParameters);

	}

	public int deleteEmploye(int empId) {

		SqlParameterSource namedParameters = new MapSqlParameterSource()
				.addValue("empId", empId);
		return namedParameterJdbcTemplate.update(
				QueryBuilder.EMPLOYEE_SQL_DELETE, namedParameters);
	}
}
