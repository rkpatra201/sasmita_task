package com.java.controllers;

import static org.mockito.Mockito.reset;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.java.model.EmployeeModel;
import com.java.services.EmployeeService;

@RestController
public class EmployeeController {

	@Autowired
	EmployeeService service;

	@RequestMapping("/")
	public String sayHello() {
		return "hello world";
	}

	@GetMapping(value = "employee-{id}")
	public ResponseEntity<EmployeeModel> getEmployeeId(
			@PathVariable("id") int empId) {
		ResponseEntity<EmployeeModel> response = new ResponseEntity<EmployeeModel>(
				new EmployeeModel(empId, "rabi", "tecksystem"),

				HttpStatus.OK);

		return response;
	}

	@PostMapping("employee-add")
	public ResponseEntity<String> addEmployee(@RequestBody EmployeeModel model) {
		int id = service.addEmployee(model);

		ResponseEntity<String> response = new ResponseEntity<String>(
				"rows affected : " + id, HttpStatus.OK);

		return response;
	}

	@PostMapping("employee-update")
	public ResponseEntity<String> updateEmployee(
			@RequestBody EmployeeModel model) {
		int id = service.updateEmployee(model);
		ResponseEntity<String> response = new ResponseEntity<String>(
				"updated row:" + id, HttpStatus.OK);
		return response;

	}

	// first do insert
	// okk
	@GetMapping("employee-delete-{id}")
	public ResponseEntity<String> deleteEmployee(@PathVariable("id") int empId) {
		int id = service.deleteEmployee(empId);
		ResponseEntity<String> response = new ResponseEntity<String>(
				"delete row:" + id, HttpStatus.OK);
		return response;
	}

}
