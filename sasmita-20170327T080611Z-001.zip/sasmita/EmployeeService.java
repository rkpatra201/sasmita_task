package com.java.services;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.java.model.EmployeeModel;
import com.java.repositories.EmployeeDao;

@Service
public class EmployeeService {

	@Autowired
	EmployeeDao dao;

	@Transactional
	public int addEmployee(EmployeeModel model) {
		return dao.insertEmployee(model);
	}

	public int updateEmployee(EmployeeModel model) {
		// TODO Auto-generated method stub
		return dao.updateEmployee(model);
	}
	public int deleteEmployee(int empId){
		return dao.deleteEmploye(empId);
		
		
	}
}
