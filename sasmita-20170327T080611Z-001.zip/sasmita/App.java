package com.spring.spring_boot_jdbc_example_1;
	public class App 
	{
	    public static void main( String[] args )
	    {
	        System.out.println( "Hello World!" );
	    }
	}


